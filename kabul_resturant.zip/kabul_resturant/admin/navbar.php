<nav>
        <a href="/kabul_resturant">Home</a>
        <a href="./foods.php">Foods</a>
        <a href="./order.php">Order</a>
        <a href="./logout.php">Logout</a>
    </nav>