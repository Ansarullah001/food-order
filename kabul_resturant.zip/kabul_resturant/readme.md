# Simple Project 

## Usage
Clone the repo:

```bash
git clone https://github.com/Nawabi-Hamza/omnifood.git
```

Open Project:

```bash
click on index.html
```




# `Project` 
<img src="./Screenshot 2024-11-09 at 20-52-45 Omnifood - Never Cook Again.png" style="width:100%;height:100%;">